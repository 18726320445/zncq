package com.igeek.zncq.service.Impl;

import com.igeek.zncq.service.IOrderService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author 刘燚
 * @version v1.0.0
 * @Description TODO
 * @createDate：2023/2/23 15:29
 * @email liuyia2022@163.com
 */
@Transactional(rollbackFor = {})
@Service
public class OrderServiceImpl implements IOrderService {

}

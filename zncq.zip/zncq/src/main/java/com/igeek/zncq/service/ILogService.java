package com.igeek.zncq.service;

import com.igeek.zncq.entity.Log;

/**
 * @author liuyi
 */

public interface ILogService {
    void save(Log log);
}

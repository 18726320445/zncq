package com.igeek.zncq.vo;

import lombok.Data;

/**
 * @author 刘燚
 * @version v1.0.0
 * @Description TODO
 * @createDate：2023/2/21 18:38
 * @email liuyia2022@163.com
 */
@Data
public class PurchaseGoodVo {
    private String purchaseNo;
    private Integer goodId;
    private String goodName;
    private Long num;
}

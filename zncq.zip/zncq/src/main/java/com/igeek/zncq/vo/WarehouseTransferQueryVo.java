package com.igeek.zncq.vo;

import lombok.Data;

/**
 * @author 刘燚
 * @version v1.0.0
 * @Description TODO
 * @createDate：2023/3/2 10:59
 * @email liuyia2022@163.com
 */
@Data
public class WarehouseTransferQueryVo {
    private Integer pageNum;
    private String goodName;
    private Integer state;
}

package com.igeek.zncq.vo;

import lombok.Data;

/**
 * @author 刘燚
 * @version v1.0.0
 * @Description TODO
 * @createDate：2023/2/15 09:52
 * @email liuyia2022@163.com
 */
@Data
public class WarehouseQueryVo {
    private Integer pageNum;
    private String name;
    private String admin;
    private String address;
}

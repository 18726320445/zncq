package com.igeek.zncq.vo;

import lombok.Data;

/**
 * @author 刘燚
 * @version v1.0.0
 * @Description TODO
 * @createDate：2023/3/6 19:07
 * @email liuyia2022@163.com
 */
@Data
public class UserQueryVo {
    private Integer pageNum;
    private Integer state;
    private String username;
}

package com.igeek.zncq.vo;

import lombok.Data;

/**
 * @author 刘燚
 * @version v1.0.0
 * @Description TODO
 * @createDate：2023/2/19 19:00
 * @email liuyia2022@163.com
 */
@Data
public class WarehouseAndContainerVo {
    private Integer warehouseId;
    private Integer containerId;
    private Long num;
}

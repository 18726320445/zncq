package com.igeek.zncq.vo;


import lombok.Data;

/**
 * @author 刘燚
 * @version v1.0.0
 * @Description TODO
 * @createDate：2023/2/17 19:10
 * @email liuyia2022@163.com
 */
@Data
public class VehicleQueryVo {
    private Integer pageNum;
    private String name;
    private String vehicleNo;
    private String admin;
}

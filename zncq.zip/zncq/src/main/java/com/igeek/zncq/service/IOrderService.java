package com.igeek.zncq.service;

/**
 * @author liuyi
 */
public interface IOrderService {
}

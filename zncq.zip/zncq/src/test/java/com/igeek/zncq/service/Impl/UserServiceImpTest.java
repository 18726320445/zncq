package com.igeek.zncq.service.Impl;

import com.igeek.zncq.entity.User;
import com.igeek.zncq.service.IUserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceImpTest {
    @Autowired
    IUserService userService;

}
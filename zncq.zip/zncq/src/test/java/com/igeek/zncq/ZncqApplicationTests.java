package com.igeek.zncq;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZncqApplicationTests {

}
